.onLoad <- function(libname, pkgname) {
  # Exercise 4 TBD

  invisible(NULL)
}