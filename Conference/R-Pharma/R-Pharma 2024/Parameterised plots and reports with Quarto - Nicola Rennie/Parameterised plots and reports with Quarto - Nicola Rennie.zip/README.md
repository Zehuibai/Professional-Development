# Parameterized plots and reports with R and Quarto

Workshop website: [nrennie.rbind.io/r-pharma-2024-parameterized-reports](https://nrennie.rbind.io/r-pharma-2024-parameterized-reports)

## Prerequisites

We'll be using the following R packages:

* dplyr
* gapminder
* ggplot2
* glue
* purrr
* quarto

You'll also need to have [Quarto](https://quarto.org/) installed.
